# rkt version

This command prints the rkt version, the appc version rkt is built against, and the Go version and architecture rkt was built with.

## Example

```
$ rkt version
rkt Version: 1.9.1
appc Version: 0.7.4
Go Version: go1.5.3
Go OS/Arch: linux/amd64
