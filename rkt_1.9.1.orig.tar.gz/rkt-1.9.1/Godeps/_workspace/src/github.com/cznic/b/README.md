b
=

Package b implements a B+tree.

Installation:

    $ go get github.com/cznic/b

Documentation: [godoc.org/github.com/cznic/b](http://godoc.org/github.com/cznic/b)
