zappy
=====

Package zappy implements the zappy block-based compression format.  It aims for
a combination of good speed and reasonable compression.

Installation: $ go get github.com/cznic/zappy

Documentation: [godoc.org/github.com/cznic/zappy](http://godoc.org/github.com/cznic/zappy)
