lldb
====

Package lldb (WIP) implements a low level database engine.

Installation: $ go get github.com/cznic/exp/lldb

Documentation: [godoc.org/github.com/cznic/exp/lldb](http://godoc.org/github.com/cznic/exp/lldb)
