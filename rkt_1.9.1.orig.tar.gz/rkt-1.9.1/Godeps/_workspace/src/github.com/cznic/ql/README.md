ql
==

Package ql is a pure Go embedded (S)QL database.

Installation

    $ go get github.com/cznic/ql

Documentation: [godoc.org/github.com/cznic/ql](http://godoc.org/github.com/cznic/ql)

----

Accompanying tool to play with a DB

Installation

    $ go get github.com/cznic/ql/ql

Documentation: [godoc.org/github.com/cznic/ql/ql](http://godoc.org/github.com/cznic/ql/ql)

