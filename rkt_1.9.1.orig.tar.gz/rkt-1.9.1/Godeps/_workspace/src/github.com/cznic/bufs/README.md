bufs
====

Package bufs implements a simple buffer cache.

 installation: go get github.com/cznic/bufs

documentation: http://godoc.org/github.com/cznic/bufs
