wmi
===

Package wmi provides a WQL interface for WMI on Windows.
