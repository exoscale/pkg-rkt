# DHCP4 - A DHCP library written in Go.

Warning: This library is still being developed.  Function calls will change.

I've removed Server Functionality, for me this project supports the underlying DHCP format not the implementation.
