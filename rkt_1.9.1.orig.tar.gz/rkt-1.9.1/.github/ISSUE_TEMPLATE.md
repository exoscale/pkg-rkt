**Environment**

Replace this with the output of:

`printf "$(rkt version)\n--\n$(uname -srm)\n--\n$(cat /etc/os-release)\n--\n$(systemctl --version)"`

**What did you do?**

**What did you expect to see?**

**What did you see instead?**
